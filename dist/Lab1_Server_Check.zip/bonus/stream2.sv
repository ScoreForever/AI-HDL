`timescale 1ns/1ps
module tb;
 reg clk=0;always #5 clk=~clk;
 reg rstn=0,en=0;reg [511:0] x=0;reg [287:0] w=0;
 wire [127:0] y;wire vld;reg [127:0] golden,q0,q1,q2;
 reg a0=0,a1=0,a2=0;integer fd,n=0,rc,rv,ev,checked=0;
 winograd_2d dut(clk,rstn,en,x,w,y,vld);
 initial begin
  $dumpfile("stream2.vcd");$dumpvars(0,tb);
  fd=$fopen("vectors2.txt","r");
  while(!$feof(fd)) begin
   @(negedge clk); rc=$fscanf(fd,"%d %d %h %h %h\n",rv,ev,x,w,golden);
   if(rc!=5) $fatal(1,"bad vector");rstn=rv;en=ev;
   @(posedge clk);
   if(!rstn) begin a0=0;a1=0;a2=0;q0=0;q1=0;q2=0;end
   else begin a2=a1;a1=a0;a0=en;q2=q1;q1=q0;q0=golden;end
   #1;
   if(vld!==a2) $fatal(1,"valid mismatch cycle %d",n);
   if(a2) begin if(y!==q2) $fatal(1,"arithmetic mismatch cycle %d expected %h got %h",n,q2,y);checked=checked+1;end
   if(!rstn && y!==0) $fatal(1,"reset output mismatch");n=n+1;
  end
  $display("ALL PASS: 2D streaming %0d cycles, %0d checked outputs",n,checked);$finish;
 end
endmodule
